# Building an Android APK

This archive contains the Expo mobile app plus the shared API client it uses.

## Requirements

- Node.js 20 or newer
- pnpm
- Android Studio with the Android SDK and an emulator or USB device
- A reachable API server URL

## Build steps

From the extracted archive root:

```bash
pnpm install
export EXPO_PUBLIC_DOMAIN="your-api-domain.example"
cd artifacts/cattle-ai-mobile
pnpm exec expo prebuild --platform android
cd android
./gradlew assembleRelease
```

The APK will be generated at:

```text
artifacts/cattle-ai-mobile/android/app/build/outputs/apk/release/app-release.apk
```

For a debug APK, use `./gradlew assembleDebug` instead.