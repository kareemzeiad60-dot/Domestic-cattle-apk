import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

type Language = 'ar' | 'en';
type LanguageContextValue = {
  language: Language;
  isArabic: boolean;
  toggleLanguage: () => void;
  t: (ar: string, en: string) => string;
};

const LanguageContext = createContext<LanguageContextValue | null>(null);
const STORAGE_KEY = 'cattle-ai-language';

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>('ar');

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((value) => {
      if (value === 'ar' || value === 'en') setLanguage(value);
    });
  }, []);

  const value = useMemo<LanguageContextValue>(() => ({
    language,
    isArabic: language === 'ar',
    toggleLanguage: () => {
      const next = language === 'ar' ? 'en' : 'ar';
      setLanguage(next);
      void AsyncStorage.setItem(STORAGE_KEY, next);
    },
    t: (ar, en) => language === 'ar' ? ar : en,
  }), [language]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within LanguageProvider');
  return context;
}