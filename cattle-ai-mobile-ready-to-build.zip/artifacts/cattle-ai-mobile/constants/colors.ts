/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const palette = {
  text: '#F8FAFC',
  tint: '#3DED97',
  background: '#0B0E13',
  foreground: '#F8FAFC',
  card: '#0F172A',
  cardForeground: '#F8FAFC',
  primary: '#3DED97',
  primaryForeground: '#0B0E13',
  secondary: '#1F2937',
  secondaryForeground: '#F8FAFC',
  muted: '#111827',
  mutedForeground: '#9CA3AF',
  accent: '#3DED97',
  accentForeground: '#0B0E13',
  destructive: '#F87171',
  destructiveForeground: '#0B0E13',
  border: '#1F2937',
  input: '#1F2937',
};

const colors = {
  light: palette,
  dark: palette,
  radius: 8,
};

export default colors;
