import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { File } from 'expo-file-system';
import { Ionicons } from '@expo/vector-icons';
import { useQueryClient } from '@tanstack/react-query';
import { getGetTrainingStatusQueryKey, useGetTrainingStatus, useStartTraining, type TrainingStatus } from '@workspace/api-client-react';
import { Screen, AppHeader, SectionLabel } from '@/components/AppChrome';
import { useColors } from '@/hooks/useColors';
import { useLanguage } from '@/lib/language-context';

export default function TrainScreen() {
  const colors = useColors();
  const { t, isArabic } = useLanguage();
  const queryClient = useQueryClient();
  const status = useGetTrainingStatus({ query: { queryKey: getGetTrainingStatusQueryKey(), refetchInterval: 2500, staleTime: 0 } });
  const startTraining = useStartTraining();
  const [dataset, setDataset] = useState<{ name: string; uri: string } | null>(null);

  useEffect(() => {
    if (status.data?.state === 'completed' || status.data?.state === 'failed') {
      setDataset(null);
    }
  }, [status.data?.state]);

  const pickDataset = async () => {
    const result = await DocumentPicker.getDocumentAsync({ type: 'application/zip', copyToCacheDirectory: true, multiple: false });
    if (!result.canceled && result.assets[0]) {
      setDataset({ name: result.assets[0].name, uri: result.assets[0].uri });
    }
  };

  const beginTraining = async () => {
    if (!dataset) return;
    try {
      const datasetData = await new File(dataset.uri).base64();
      startTraining.mutate(
        { data: { datasetName: dataset.name, datasetData } },
        {
          onSuccess: () => void queryClient.invalidateQueries({ queryKey: getGetTrainingStatusQueryKey() }),
          onError: (error) => Alert.alert(t('تعذر بدء التدريب', 'Could not start training'), error.message),
        },
      );
    } catch {
      Alert.alert(t('تعذر قراءة الملف', 'Could not read file'), t('تأكد من اختيار ملف ZIP صالح.', 'Make sure you selected a valid ZIP file.'));
    }
  };

  const current = status.data;
  const running = current?.state === 'running' || current?.state === 'queued' || startTraining.isPending;

  return (
    <Screen>
      <AppHeader title={t('إعادة تدريب النموذج', 'Retrain the model')} subtitle={t('أضف بيانات مصنفة لتحسين دقة السلالات.', 'Add labeled data to improve breed accuracy.')} />

      <View style={[styles.infoCard, { borderColor: colors.primary + '45', backgroundColor: colors.primary + '10' }]}>
        <View style={[styles.infoIcon, { backgroundColor: colors.primary + '18' }]}><Ionicons name="information-circle-outline" size={24} color={colors.primary} /></View>
        <Text style={[styles.infoText, { color: colors.foreground, textAlign: isArabic ? 'right' : 'left' }]}>
          {t('ارفع ملف ZIP يحتوي مجلدًا لكل سلالة، وكل مجلد يحتوي صورها. يفضل 10 صور على الأقل لكل سلالة.', 'Upload a ZIP with one folder per breed, each containing its images. At least 10 images per breed is recommended.')}
        </Text>
      </View>

      <SectionLabel>{t('مجموعة البيانات', 'DATASET')}</SectionLabel>
      <Pressable testID="pick-dataset" onPress={() => void pickDataset()} disabled={running} style={({ pressed }) => [styles.datasetPicker, { borderColor: dataset ? colors.primary : colors.border, backgroundColor: colors.card, opacity: pressed || running ? 0.72 : 1 }]}>
        <View style={[styles.fileIcon, { backgroundColor: colors.primary + '18' }]}><Ionicons name="file-tray-full-outline" size={25} color={colors.primary} /></View>
        <View style={styles.fileCopy}>
          <Text style={[styles.fileTitle, { color: colors.foreground }]} numberOfLines={1}>{dataset?.name ?? t('اختر ملف البيانات', 'Choose dataset file')}</Text>
          <Text style={[styles.fileMeta, { color: colors.mutedForeground }]}>{dataset ? t('جاهز للرفع', 'Ready to upload') : t('ملف ZIP فقط', 'ZIP file only')}</Text>
        </View>
        <Ionicons name="chevron-forward" size={20} color={colors.mutedForeground} />
      </Pressable>

      <Pressable testID="start-training" onPress={() => void beginTraining()} disabled={!dataset || running} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary, opacity: !dataset || running || pressed ? 0.65 : 1 }]}>
        {running ? <ActivityIndicator color={colors.primaryForeground} /> : <Ionicons name="rocket-outline" size={21} color={colors.primaryForeground} />}
        <Text style={[styles.primaryText, { color: colors.primaryForeground }]}>{running ? t('التدريب جارٍ...', 'Training in progress...') : t('ابدأ إعادة التدريب', 'Start retraining')}</Text>
      </Pressable>

      {current ? <TrainingCard current={current} colors={colors} t={t} isArabic={isArabic} /> : null}
    </Screen>
  );
}

function TrainingCard({ current, colors, t, isArabic }: { current: TrainingStatus; colors: ReturnType<typeof useColors>; t: (ar: string, en: string) => string; isArabic: boolean }) {
  const stateLabel = current.state === 'completed' ? t('اكتمل التدريب', 'Training complete') : current.state === 'failed' ? t('تعذر إكمال التدريب', 'Training failed') : current.state === 'idle' ? t('جاهز للتدريب', 'Ready to train') : t('التدريب يعمل', 'Training is active');
  const stateColor = current.state === 'failed' ? colors.destructive : current.state === 'completed' ? colors.primary : colors.foreground;
  return (
    <View style={[styles.trainingCard, { borderColor: current.state === 'failed' ? colors.destructive + '70' : colors.border, backgroundColor: colors.card }]}>
      <View style={styles.trainingHeader}>
        <View style={styles.trainingTitleRow}>
          <View style={[styles.stateDot, { backgroundColor: stateColor }]} />
          <Text style={[styles.trainingTitle, { color: stateColor }]}>{stateLabel}</Text>
        </View>
        <Text style={[styles.progressValue, { color: colors.primary }]}>{current.progress}%</Text>
      </View>
      <View style={[styles.progressTrack, { backgroundColor: colors.muted }]}>
        <View style={[styles.progressFill, { width: `${current.progress}%`, backgroundColor: stateColor }]} />
      </View>
      <Text style={[styles.statusMessage, { color: colors.mutedForeground, textAlign: isArabic ? 'right' : 'left' }]}>{current.message}</Text>
      {current.datasetName ? <Text style={[styles.datasetName, { color: colors.foreground }]} numberOfLines={1}>{current.datasetName}</Text> : null}
      {current.accuracy !== null ? <View style={[styles.accuracyRow, { borderTopColor: colors.border }]}><Text style={[styles.accuracyLabel, { color: colors.mutedForeground }]}>{t('دقة التحقق', 'Validation accuracy')}</Text><Text style={[styles.accuracyValue, { color: colors.primary }]}>{Math.round(current.accuracy * 100)}%</Text></View> : null}
      {current.breeds.length > 0 ? <Text style={[styles.breeds, { color: colors.mutedForeground }]}>{current.breeds.join(' · ')}</Text> : null}
      {current.error ? <Text style={[styles.error, { color: colors.destructive }]}>{current.error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  infoCard: { borderWidth: 1, borderRadius: 18, padding: 16, flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 24 },
  infoIcon: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  infoText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20 },
  datasetPicker: { borderWidth: 1, borderRadius: 17, padding: 14, flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  fileIcon: { width: 46, height: 46, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  fileCopy: { flex: 1 },
  fileTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  fileMeta: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 4 },
  primaryButton: { minHeight: 58, borderRadius: 16, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 9, marginBottom: 22 },
  primaryText: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  trainingCard: { borderWidth: 1, borderRadius: 20, padding: 18 },
  trainingHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  trainingTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  stateDot: { width: 8, height: 8, borderRadius: 4 },
  trainingTitle: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  progressValue: { fontFamily: 'Inter_700Bold', fontSize: 20 },
  progressTrack: { height: 10, borderRadius: 5, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 5 },
  statusMessage: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20, marginTop: 12 },
  datasetName: { fontFamily: 'Inter_600SemiBold', fontSize: 13, marginTop: 8 },
  accuracyRow: { borderTopWidth: 1, marginTop: 16, paddingTop: 14, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  accuracyLabel: { fontFamily: 'Inter_400Regular', fontSize: 12 },
  accuracyValue: { fontFamily: 'Inter_700Bold', fontSize: 18 },
  breeds: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 18, marginTop: 14 },
  error: { fontFamily: 'Inter_500Medium', fontSize: 12, lineHeight: 18, marginTop: 12 },
});