import React from 'react';
import { ActivityIndicator, FlatList, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getListAnalysesQueryKey, useListAnalyses, type Analysis } from '@workspace/api-client-react';
import { Screen, AppHeader } from '@/components/AppChrome';
import { useColors } from '@/hooks/useColors';
import { useLanguage } from '@/lib/language-context';

export default function HistoryScreen() {
  const colors = useColors();
  const { t, isArabic } = useLanguage();
  const listParams = { limit: 30 };
  const analyses = useListAnalyses(listParams, { query: { queryKey: getListAnalysesQueryKey(listParams), refetchOnWindowFocus: false } });

  return (
    <Screen scroll={false}>
      <AppHeader title={t('سجل الفحوصات', 'Analysis history')} subtitle={t('كل قراءة محفوظة في مكان واحد.', 'Every reading, kept in one place.')} />
      {analyses.isLoading ? (
        <View style={styles.center}><ActivityIndicator color={colors.primary} size="large" /></View>
      ) : analyses.isError ? (
        <View style={[styles.empty, { borderColor: colors.border, backgroundColor: colors.card }]}>
          <Ionicons name="cloud-offline-outline" size={34} color={colors.mutedForeground} />
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{t('تعذر تحميل السجل', 'Could not load history')}</Text>
          <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>{t('اسحب لأسفل للمحاولة مرة أخرى.', 'Pull down to try again.')}</Text>
        </View>
      ) : (
        <FlatList
          data={analyses.data ?? []}
          keyExtractor={(item) => String(item.id)}
          refreshControl={<RefreshControl refreshing={analyses.isFetching} onRefresh={() => void analyses.refetch()} tintColor={colors.primary} />}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 30, flexGrow: analyses.data?.length ? 0 : 1 }}
          ListEmptyComponent={
            <View style={[styles.empty, { borderColor: colors.border, backgroundColor: colors.card }]}>
              <Ionicons name="file-tray-outline" size={34} color={colors.primary} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{t('لا توجد فحوصات بعد', 'No scans yet')}</Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>{t('ابدأ من تبويب التحليل لرؤية النتائج هنا.', 'Start from the scan tab to see results here.')}</Text>
            </View>
          }
          renderItem={({ item }) => <AnalysisRow item={item} colors={colors} isArabic={isArabic} />}
        />
      )}
    </Screen>
  );
}

function AnalysisRow({ item, colors, isArabic }: { item: Analysis; colors: ReturnType<typeof useColors>; isArabic: boolean }) {
  const date = new Date(item.createdAt).toLocaleDateString(isArabic ? 'ar-EG' : 'en-US', { day: 'numeric', month: 'short', year: 'numeric' });
  return (
    <View style={[styles.row, { borderColor: colors.border, backgroundColor: colors.card }]}>
      <View style={[styles.rowIcon, { backgroundColor: colors.primary + '18' }]}>
        <Ionicons name="analytics-outline" size={22} color={colors.primary} />
      </View>
      <View style={styles.rowCopy}>
        <Text style={[styles.breed, { color: colors.foreground }]} numberOfLines={1}>{item.topBreed}</Text>
        <Text style={[styles.date, { color: colors.mutedForeground }]}>{date}</Text>
      </View>
      <View style={styles.score}>
        <Text style={[styles.scoreValue, { color: colors.primary }]}>{Math.round(item.topConfidence * 100)}%</Text>
        <Text style={[styles.scoreLabel, { color: colors.mutedForeground }]}>match</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  row: { borderWidth: 1, borderRadius: 16, padding: 14, flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  rowIcon: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  rowCopy: { flex: 1 },
  breed: { fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  date: { fontFamily: 'Inter_400Regular', fontSize: 12, marginTop: 4 },
  score: { alignItems: 'flex-end', marginLeft: 10 },
  scoreValue: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  scoreLabel: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 3 },
  empty: { flex: 1, minHeight: 220, borderWidth: 1, borderRadius: 18, borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center', padding: 22, marginTop: 8 },
  emptyTitle: { fontFamily: 'Inter_700Bold', fontSize: 17, marginTop: 12 },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 13, textAlign: 'center', lineHeight: 20, marginTop: 6, maxWidth: 260 },
});