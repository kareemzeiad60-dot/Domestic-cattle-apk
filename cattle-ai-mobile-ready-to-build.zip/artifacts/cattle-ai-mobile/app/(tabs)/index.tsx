import React, { useState } from 'react';
import { ActivityIndicator, Alert, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { File } from 'expo-file-system';
import { Ionicons } from '@expo/vector-icons';
import { useQueryClient } from '@tanstack/react-query';
import { getListAnalysesQueryKey, useCreateAnalysis } from '@workspace/api-client-react';
import { Screen, AppHeader, SectionLabel } from '@/components/AppChrome';
import { useColors } from '@/hooks/useColors';
import { useLanguage } from '@/lib/language-context';

export default function AnalyzeScreen() {
  const colors = useColors();
  const { t, isArabic } = useLanguage();
  const queryClient = useQueryClient();
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [imageName, setImageName] = useState('');
  const [result, setResult] = useState<Awaited<ReturnType<typeof import('@workspace/api-client-react').createAnalysis>> | null>(null);
  const createAnalysis = useCreateAnalysis();

  const selectImage = async (source: 'camera' | 'library') => {
    const permission = source === 'camera'
      ? await ImagePicker.requestCameraPermissionsAsync()
      : await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert(t('نحتاج إذن الصور والكاميرا', 'Permission needed'), t('اسمح بالوصول لاختيار صورة الماشية.', 'Allow access to choose a cattle image.'));
      return;
    }
    const picker = source === 'camera'
      ? await ImagePicker.launchCameraAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.82 })
      : await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.82 });
    if (!picker.canceled && picker.assets[0]) {
      setImageUri(picker.assets[0].uri);
      setImageName(picker.assets[0].fileName ?? `${source}-${Date.now()}.jpg`);
      setResult(null);
    }
  };

  const analyze = async () => {
    if (!imageUri) return;
    try {
      const imageData = `data:image/jpeg;base64,${await new File(imageUri).base64()}`;
      createAnalysis.mutate(
        { data: { imageData, imageName } },
        {
          onSuccess: (data) => {
            setResult(data);
            void queryClient.invalidateQueries({ queryKey: getListAnalysesQueryKey() });
          },
          onError: (error) => Alert.alert(t('تعذر التحليل', 'Analysis failed'), error.message),
        },
      );
    } catch {
      Alert.alert(t('تعذر قراءة الصورة', 'Could not read image'), t('حاول اختيار صورة أخرى.', 'Try selecting another image.'));
    }
  };

  return (
    <Screen>
      <AppHeader
        title={t('حلّل سلالة', 'Identify a breed')}
        subtitle={t('التقط صورة واحصل على قراءة فورية من النموذج.', 'Take a photo and get an instant model reading.')}
      />

      <View style={[styles.heroCard, { borderColor: colors.border, backgroundColor: colors.card }]}>
        <View style={[styles.heroGlow, { backgroundColor: colors.primary }]} />
        <Image source={require('../../assets/images/icon.png')} style={styles.logo} />
        <View style={styles.heroText}>
          <Text style={[styles.heroTitle, { color: colors.foreground, textAlign: isArabic ? 'right' : 'left' }]}>
            {t('مساعد المربي الذكي', 'Your intelligent herd assistant')}
          </Text>
          <Text style={[styles.heroDescription, { color: colors.mutedForeground, textAlign: isArabic ? 'right' : 'left' }]}>
            {t('صور واضحة، نتائج أدق، وسجل كامل لكل فحص.', 'Clear photos, sharper results, and a complete record for every scan.')}
          </Text>
        </View>
      </View>

      <SectionLabel>{t('صورة الماشية', 'CATTLE IMAGE')}</SectionLabel>
      {imageUri ? (
        <View style={[styles.previewCard, { borderColor: colors.primary }]}>
          <Image source={{ uri: imageUri }} style={styles.preview} />
          <Pressable
            testID="clear-image"
            onPress={() => { setImageUri(null); setResult(null); }}
            style={({ pressed }) => [styles.clearButton, { backgroundColor: colors.background, opacity: pressed ? 0.7 : 1 }]}
          >
            <Ionicons name="close" size={20} color={colors.foreground} />
          </Pressable>
        </View>
      ) : (
        <View style={[styles.emptyUpload, { borderColor: colors.border, backgroundColor: colors.card }]}>
          <View style={[styles.uploadIcon, { backgroundColor: colors.primary + '18' }]}>
            <Ionicons name="scan-outline" size={30} color={colors.primary} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{t('ابدأ بفحص جديد', 'Start a new scan')}</Text>
          <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>{t('استخدم الكاميرا أو اختر صورة من الهاتف.', 'Use the camera or choose a photo from your phone.')}</Text>
        </View>
      )}

      <View style={styles.actionRow}>
        <ActionButton icon="camera-outline" label={t('كاميرا', 'Camera')} onPress={() => void selectImage('camera')} colors={colors} />
        <ActionButton icon="images-outline" label={t('المعرض', 'Gallery')} onPress={() => void selectImage('library')} colors={colors} />
      </View>

      {imageUri && !result ? (
        <Pressable
          testID="analyze-button"
          onPress={() => void analyze()}
          disabled={createAnalysis.isPending}
          style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary, opacity: pressed || createAnalysis.isPending ? 0.72 : 1 }]}
        >
          {createAnalysis.isPending ? <ActivityIndicator color={colors.primaryForeground} /> : <Ionicons name="sparkles-outline" size={21} color={colors.primaryForeground} />}
          <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>{t('تحليل الصورة', 'Analyze image')}</Text>
        </Pressable>
      ) : null}

      {createAnalysis.isPending ? (
        <View style={[styles.processingCard, { borderColor: colors.border, backgroundColor: colors.card }]}>
          <ActivityIndicator color={colors.primary} />
          <View style={styles.processingCopy}>
            <Text style={[styles.processingTitle, { color: colors.foreground }]}>{t('النموذج يعمل الآن', 'The model is working')}</Text>
            <Text style={[styles.processingText, { color: colors.mutedForeground }]}>{t('يتم استخراج السمات البصرية...', 'Extracting visual features...')}</Text>
          </View>
        </View>
      ) : null}

      {result ? <ResultCard result={result} colors={colors} isArabic={isArabic} t={t} /> : null}
    </Screen>
  );
}

function ActionButton({ icon, label, onPress, colors }: { icon: keyof typeof Ionicons.glyphMap; label: string; onPress: () => void; colors: ReturnType<typeof useColors> }) {
  return (
    <Pressable testID={`action-${label}`} onPress={onPress} style={({ pressed }) => [styles.actionButton, { borderColor: colors.border, backgroundColor: colors.card, opacity: pressed ? 0.72 : 1 }]}>
      <Ionicons name={icon} size={22} color={colors.primary} />
      <Text style={[styles.actionText, { color: colors.foreground }]}>{label}</Text>
    </Pressable>
  );
}

function ResultCard({ result, colors, isArabic, t }: { result: NonNullable<Awaited<ReturnType<typeof import('@workspace/api-client-react').createAnalysis>>>; colors: ReturnType<typeof useColors>; isArabic: boolean; t: (ar: string, en: string) => string }) {
  return (
    <View style={[styles.resultCard, { borderColor: colors.primary + '70', backgroundColor: colors.card }]}>
      <View style={styles.resultHeader}>
        <View>
          <Text style={[styles.resultEyebrow, { color: colors.mutedForeground }]}>{t('النتيجة الأعلى', 'TOP MATCH')}</Text>
          <Text style={[styles.resultBreed, { color: colors.foreground, textAlign: isArabic ? 'right' : 'left' }]}>{result.topBreed}</Text>
        </View>
        <View style={[styles.confidence, { backgroundColor: colors.primary + '18', borderColor: colors.primary + '60' }]}>
          <Text style={[styles.confidenceValue, { color: colors.primary }]}>{Math.round(result.topConfidence * 100)}%</Text>
          <Text style={[styles.confidenceLabel, { color: colors.mutedForeground }]}>{t('ثقة', 'confidence')}</Text>
        </View>
      </View>
      {result.predictions.slice(0, 3).map((prediction) => (
        <View key={prediction.breed} style={styles.predictionRow}>
          <View style={styles.predictionMeta}>
            <Text style={[styles.predictionBreed, { color: colors.foreground }]}>{prediction.breed}</Text>
            <Text style={[styles.predictionValue, { color: colors.mutedForeground }]}>{Math.round(prediction.confidence * 100)}%</Text>
          </View>
          <View style={[styles.track, { backgroundColor: colors.muted }]}>
            <View style={[styles.fill, { width: `${Math.max(4, prediction.confidence * 100)}%`, backgroundColor: prediction.rank === 1 ? colors.primary : colors.mutedForeground }]} />
          </View>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  heroCard: { minHeight: 142, borderWidth: 1, borderRadius: 20, padding: 18, flexDirection: 'row', alignItems: 'center', overflow: 'hidden', marginBottom: 24 },
  heroGlow: { position: 'absolute', width: 180, height: 180, borderRadius: 90, opacity: 0.08, right: -70, top: -40 },
  logo: { width: 78, height: 78, borderRadius: 22, marginRight: 16 },
  heroText: { flex: 1 },
  heroTitle: { fontFamily: 'Inter_700Bold', fontSize: 19, lineHeight: 25 },
  heroDescription: { fontFamily: 'Inter_400Regular', fontSize: 13, lineHeight: 20, marginTop: 7 },
  emptyUpload: { minHeight: 190, borderWidth: 1, borderStyle: 'dashed', borderRadius: 18, alignItems: 'center', justifyContent: 'center', padding: 22 },
  uploadIcon: { width: 62, height: 62, borderRadius: 31, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  emptyTitle: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  emptyText: { fontFamily: 'Inter_400Regular', fontSize: 13, textAlign: 'center', lineHeight: 20, marginTop: 6, maxWidth: 260 },
  previewCard: { height: 230, borderWidth: 1, borderRadius: 18, overflow: 'hidden', position: 'relative' },
  preview: { width: '100%', height: '100%', resizeMode: 'cover' },
  clearButton: { position: 'absolute', top: 12, right: 12, width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  actionRow: { flexDirection: 'row', gap: 12, marginTop: 14, marginBottom: 22 },
  actionButton: { flex: 1, minHeight: 56, borderWidth: 1, borderRadius: 15, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8 },
  actionText: { fontFamily: 'Inter_600SemiBold', fontSize: 14 },
  primaryButton: { minHeight: 58, borderRadius: 16, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 9, marginBottom: 18 },
  primaryButtonText: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  processingCard: { minHeight: 78, borderWidth: 1, borderRadius: 16, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 18 },
  processingCopy: { flex: 1 },
  processingTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  processingText: { fontFamily: 'Inter_400Regular', fontSize: 13, marginTop: 4 },
  resultCard: { borderWidth: 1, borderRadius: 20, padding: 18, marginBottom: 22 },
  resultHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  resultEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.2, marginBottom: 6 },
  resultBreed: { fontFamily: 'Inter_700Bold', fontSize: 23 },
  confidence: { borderWidth: 1, borderRadius: 16, minWidth: 70, paddingVertical: 10, alignItems: 'center' },
  confidenceValue: { fontFamily: 'Inter_700Bold', fontSize: 18 },
  confidenceLabel: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 2 },
  predictionRow: { marginBottom: 13 },
  predictionMeta: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 7 },
  predictionBreed: { fontFamily: 'Inter_500Medium', fontSize: 13 },
  predictionValue: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  track: { height: 7, borderRadius: 4, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: 4 },
});