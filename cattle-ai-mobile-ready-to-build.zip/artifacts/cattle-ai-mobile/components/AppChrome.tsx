import React from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useLanguage } from '@/lib/language-context';

export function Screen({ children, scroll = true }: { children: React.ReactNode; scroll?: boolean }) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const paddingTop = insets.top + (Platform.OS === 'web' ? 67 : 0);
  const paddingBottom = insets.bottom + (Platform.OS === 'web' ? 34 : 18);
  const content = (
    <View style={[styles.screen, { backgroundColor: colors.background, paddingTop, paddingBottom }]}>
      <LinearGradient
        colors={[colors.card, colors.background, colors.background]}
        locations={[0, 0.42, 1]}
        style={StyleSheet.absoluteFill}
      />
      {children}
    </View>
  );
  if (!scroll) return content;
  return (
    <ScrollView
      style={{ backgroundColor: colors.background }}
      contentContainerStyle={{ flexGrow: 1, paddingTop, paddingBottom }}
      showsVerticalScrollIndicator={false}
    >
      <LinearGradient
        colors={[colors.card, colors.background, colors.background]}
        locations={[0, 0.42, 1]}
        style={StyleSheet.absoluteFill}
      />
      {children}
    </ScrollView>
  );
}

export function AppHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  const colors = useColors();
  const { isArabic, toggleLanguage } = useLanguage();
  return (
    <View style={styles.header}>
      <View style={styles.headerCopy}>
        <View style={styles.eyebrowRow}>
          <View style={[styles.statusDot, { backgroundColor: colors.primary }]} />
          <Text style={[styles.eyebrow, { color: colors.primary }]}>DOMESTIC CATTLE AI</Text>
        </View>
        <Text style={[styles.title, { color: colors.foreground, textAlign: isArabic ? 'right' : 'left' }]}>{title}</Text>
        {subtitle ? <Text style={[styles.subtitle, { color: colors.mutedForeground, textAlign: isArabic ? 'right' : 'left' }]}>{subtitle}</Text> : null}
      </View>
      <Pressable
        testID="language-toggle"
        accessibilityRole="button"
        onPress={toggleLanguage}
        style={({ pressed }) => [styles.languageButton, { borderColor: colors.border, backgroundColor: colors.card, opacity: pressed ? 0.7 : 1 }]}
      >
        <Ionicons name="language-outline" size={18} color={colors.primary} />
        <Text style={[styles.languageText, { color: colors.foreground }]}>{isArabic ? 'EN' : 'ع'}</Text>
      </Pressable>
    </View>
  );
}

export function SectionLabel({ children }: { children: React.ReactNode }) {
  const colors = useColors();
  return <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>{children}</Text>;
}

const styles = StyleSheet.create({
  screen: { flex: 1, paddingHorizontal: 20, overflow: 'hidden' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 },
  headerCopy: { flex: 1, paddingRight: 14 },
  eyebrowRow: { flexDirection: 'row', alignItems: 'center', gap: 7, marginBottom: 8 },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1.3 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, lineHeight: 36 },
  subtitle: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 21, marginTop: 6 },
  languageButton: { flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderRadius: 18, paddingHorizontal: 11, paddingVertical: 8 },
  languageText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  sectionLabel: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 10 },
});